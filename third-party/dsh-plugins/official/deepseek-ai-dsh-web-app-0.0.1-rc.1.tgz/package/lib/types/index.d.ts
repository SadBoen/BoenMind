/**
 * @deepseek-ai/dsh-web-app — the browser-surface bundle's runtime glue plugin
 * plus the bundle patch (`cordis.patch.yml`, declared by the `dsh.bundle.patch`
 * manifest field). The plugin owns the browser-surface glue: it resolves
 * the built frontend dist (workspace knowledge of this bundle, never user
 * config), mounts the `frontend-static` fallback owner over it, registers the
 * harness-source and web-surface prompt sections, the bash-visible web runtime
 * variables, and the URL line. App command-line values arrive through the
 * `webStartup` service expressions in the bundle patch.
 * @module @deepseek-ai/dsh-web-app
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Stable Cordis plugin name. */
export declare const name = "web-app";
/** Services required before the web runtime can mount. */
export declare const inject: string[];
/** Web runtime mode: production, or development when the client-plugin HMR receiver is active. */
export type WebMode = 'production' | 'development';
/** Plugin config: composed deployment settings plus per-invocation command-line values. */
export interface Config {
    /** Whether this process mounted the client-plugin HMR receiver (`dsh web --dev`). */
    mode: WebMode;
    /** Print the URL line on activation; a non-interactive layer can turn it off. */
    printUrl: boolean;
    /**
     * Register the model-visible surface context (the `app:web-surface` prompt
     * section and the `DSH_WEB_URL`/`DSH_WEB_MODE` bash variables). A one-shot
     * non-interactive layer can turn it off when its user is not in the GUI, so the
     * orientation text would be false.
     */
    surfaceContext: boolean;
    /** Explicit `--trusted-host` authorities from this invocation. */
    trustedHosts: string[];
}
export declare const Config: z<Config>;
/** Bind-dependent Web values shared by the trust fence and URL display. */
export interface WebRuntimeValues {
    /** LAN IPv4 literals sampled once when the server binds all interfaces. */
    lanAddresses: string[];
    /** LAN literals followed by explicit invocation authorities. */
    trustedHosts: string[];
}
/**
 * Resolve one LAN-trust snapshot from the active server bind.
 *
 * Derived entries are port-less IP literals: DNS rebinding needs an
 * attacker-controlled name, while an IP-literal Host is safe on any port and
 * an OS-assigned port is unknowable before bind.
 * @param bindHost - the active webserver bind host.
 * @param extra - explicit `--trusted-host` values, in argument order.
 * @returns the LAN display addresses and invocation-derived fence authorities.
 */
export declare function resolveLanTrust(bindHost: string, extra: readonly string[]): WebRuntimeValues;
/** Test hook: hosts with no built frontend dist substitute the resolver; production never touches this. */
export declare const internals: {
    resolveDistIndex: () => string;
};
/**
 * Mount the Web runtime: dist serving, surface prompt, bash runtime
 * variables, and the URL line.
 * @param ctx - plugin context carrying the httpServer service.
 * @param config - validated {@link Config}.
 * @returns nothing once the invocation's client roster and runtime contributions are registered.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map
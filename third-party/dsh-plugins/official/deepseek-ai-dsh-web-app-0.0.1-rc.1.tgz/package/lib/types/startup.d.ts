/**
 * The web app's command-line provider: it parses the `dsh --profile web` flag
 * family (`--host`, `--port`, `--dev`, `--trusted-host`) and its `--help`
 * text, then provides the immutable values as {@link WEB_STARTUP_SERVICE}.
 * Ordinary rows inject that service before reading it from lazy config.
 * @module @deepseek-ai/dsh-web-app/startup
 */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "web-startup";
/** Services required before the flags can be resolved. */
export declare const inject: string[];
/** Service provided by this ordinary plugin and injected by flag-configured rows. */
export declare const WEB_STARTUP_SERVICE = "webStartup";
/** What the web rows read from {@link WEB_STARTUP_SERVICE}. */
export interface WebStartupValues {
    /** `--host`, absent when the invocation did not name one. */
    host?: string;
    /** `--port`, absent when the invocation did not name one. */
    port?: number;
    /** Web runtime mode; `--dev` selects development, which also mounts the client-plugin reload chain. */
    mode: 'production' | 'development';
    /** Explicit `--trusted-host` authorities, in argument order. */
    trustedHosts: string[];
}
/**
 * Parse and provide the Web invocation as an ordinary Cordis service.
 * @param ctx - plugin context carrying the command line.
 * @returns nothing once values are provided, or when the command requested exit.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=startup.d.ts.map